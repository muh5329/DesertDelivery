# Desert Delivery

A small third-person motorbike courier game inspired by *Into the Wind*, set on an island generated from a
reference painting, built in **Godot 4.3** with the GL Compatibility renderer. Everything (terrain, roads, buildings, vegetation, the bike and the
rider) is generated procedurally from GDScript at start-up, so the project has no binary assets.

## Run it

1. Install Godot 4.3 (standard build) from https://godotengine.org/download.
2. Open Godot → **Import** → pick `project.godot` in this folder → **Edit** → press **F5** (Play).
   Or from a terminal: `godot --path /path/to/DesertDelivery`.

## Controls

| Action | Keys | Gamepad |
| --- | --- | --- |
| Accelerate | W / ↑ | Right trigger / A |
| Brake / reverse | S / ↓ | Left trigger / B |
| Steer | A D / ← → | Left stick |
| Handbrake (drift) | Space | X |
| Reset bike to the nearest road | R | Y |
| Look back | C | — |
| Quit | Esc | — |

## Beyond the bike

- **E** hops off the bike (when stopped) — walk with WASD, Shift to run, Space to jump, mouse / right stick to look. E next to the bike to ride again. R on foot brings you and the bike back to the nearest road.
- **Swim** — wade into the sea and the boy swims (slower, can't shoot); the bike auto-resets if it ends up in the water.
- **Pistol** — an old pistol sits on a crate at the Dunes Lookout. On foot, hold RMB / LB to aim over the shoulder and F / LMB / RB to fire. Tin cans line the farm's stone wall and the lookout bench (9 total).
- **Plane** — T / D-pad-up folds the wings out. Throttle (W) past 54 km/h, then pull back (S / ↓) to lift off. In the air the engine cruises on its own: S/↓ raises the nose, W/↑ lowers it, A/D bank, Shift boosts. To land, nose down gently and pull up just before touchdown; T folds the wings again.
- Esc twice within 3 s quits (the first press also frees the mouse; click to re-capture).

## The loop

Ride to the glowing ring at the pickup, slow to a stop inside it to load the package onto the rear
rack, then follow the compass (top-left) to the destination ring and stop again to hand it over.
Four jobs chain across the island: Villa Rosa Office (SW vineyards) → Hilltop Farm (NW massif) → Harbour
Cafe (NE town, over the strait aqueduct) → Dunes Lookout (badlands, over the gorge viaduct) → back to the Villa. Signposts at each hub point the way.

## Automated checks

All checks run inside the booted game through the test runner (`--test=NAME` loads `tests/NAME.gd`):

```
godot --headless --path . -- --autotest --deliveries=4          # drives itself, exits 0 on success
godot --headless --path . -- --test=architecture_tests          # streaming, world database, tiers, events, save/load
godot --headless --path . -- --test=edge_tests                  # brake/reverse, sea reset, camera
godot --headless --path . -- --test=feature_tests               # dismount, swim, pistol, plane
xvfb-run godot --path . --rendering-driver opengl3 -- --test=feature_shots --out=/tmp/fshots
xvfb-run godot --path . --rendering-driver opengl3 -- --test=view --nostream --nofog --out=/tmp/view
xvfb-run godot --path . --rendering-driver opengl3 -- --shots=/tmp/shots --autotest   # + screenshots
python3 world/mapgen/extract.py [painting.png]                   # regenerate data/ from the painting
```

Debug keys in game: **F3** overlay (fps, chunk, loaded chunks, entities per tier, draw calls...),
**F5/F9** quick save/load, **F6** teleport to the next hub, **F7** reload the chunk under you, **F8** toggle streaming.

## Layout

See `ARCHITECTURE.md` for the full picture; `CONTEXT.md` for the domain vocabulary.

- `core/` – `Game` root (boot + wiring), `Events` bus, `Saves`, definitions, utils
- `world/` – `WorldManager`, `WorldDatabase` (recipes per chunk, locations, hubs), `WorldStreamer` + `Chunk`, `Terrain`, `WorldKit` builders, the `Island` generator, `mapgen/extract.py`
- `entities/` – `EntityManager` (ids + simulation tiers), player (`Player`, `Rider`, `RiderModel`), vehicles (`Vehicle` base, `Bike`), camera
- `gameplay/` – `GameplayManager`, `Controls` seam, `DeliverySystem` + `JobDefinition`, `GunSystem`
- `ai/` – `Autopilot`
- `ui/` – `HUD`, `DebugOverlay`
- `data/` – island maps, `config/world.tres`, `vehicles/bike.tres`, `jobs/*.tres`
- `tests/` – test nodes and render tools
